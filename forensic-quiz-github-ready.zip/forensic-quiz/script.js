const questions = [
  {
    topic: "Fingerprints",
    question: "Which fingerprint pattern is generally the most common?",
    options: ["Arch", "Loop", "Whorl", "Composite"],
    answer: 1,
    explanation: "Loops are generally the most common fingerprint pattern. They enter and leave from the same side."
  },
  {
    topic: "Fingerprints",
    question: "What is the study of fingerprints called?",
    options: ["Serology", "Dactyloscopy", "Toxicology", "Odontology"],
    answer: 1,
    explanation: "Dactyloscopy is the scientific study and identification of fingerprints."
  },
  {
    topic: "DNA Forensics",
    question: "Which molecule carries hereditary genetic information?",
    options: ["RNA only", "Protein", "DNA", "Lipid"],
    answer: 2,
    explanation: "DNA (deoxyribonucleic acid) stores hereditary information in most living organisms."
  },
  {
    topic: "DNA Forensics",
    question: "Which biological sample can be used for DNA profiling?",
    options: ["Hair root", "Clean glass", "Plain paper", "Distilled water"],
    answer: 0,
    explanation: "A hair with attached root tissue may contain nucleated cells that can provide DNA."
  },
  {
    topic: "Crime Scene",
    question: "What is the primary purpose of securing a crime scene?",
    options: ["To question every visitor", "To prevent contamination and preserve evidence", "To clean the area", "To move all objects"],
    answer: 1,
    explanation: "Securing the scene helps prevent contamination, loss, or alteration of potential evidence."
  },
  {
    topic: "Crime Scene",
    question: "What does the chain of custody document?",
    options: ["Weather at the scene", "The suspect's travel history", "The handling and transfer of evidence", "The officer's duty roster"],
    answer: 2,
    explanation: "The chain of custody records who collected, handled, stored, and transferred evidence."
  },
  {
    topic: "Ballistics",
    question: "What does forensic ballistics primarily examine?",
    options: ["Firearms, ammunition and projectile-related evidence", "Plant samples", "Handwriting", "Blood groups"],
    answer: 0,
    explanation: "Forensic ballistics examines firearms, ammunition, bullets, cartridge cases and related evidence."
  },
  {
    topic: "Ballistics",
    question: "What is the main purpose of rifling inside a firearm barrel?",
    options: ["To reduce bullet weight", "To make the bullet spin", "To change bullet colour", "To stop the cartridge case"],
    answer: 1,
    explanation: "Rifling consists of spiral grooves that impart spin to a bullet and help stabilize its flight."
  },
  {
    topic: "Toxicology",
    question: "What is forensic toxicology concerned with?",
    options: ["Examining soil structure", "Studying poisons, drugs and chemicals in relation to legal investigations", "Classifying fingerprints", "Comparing shoe sizes"],
    answer: 1,
    explanation: "Forensic toxicology detects and interprets drugs, alcohol, poisons and other chemicals in biological samples."
  },
  {
    topic: "Toxicology",
    question: "Which sample is commonly analysed in alcohol testing?",
    options: ["Blood", "Nail polish", "Fabric dye", "Glass powder"],
    answer: 0,
    explanation: "Blood is a commonly analysed biological sample for determining alcohol concentration."
  },
  {
    topic: "Questioned Documents",
    question: "Which feature may be examined when comparing handwriting?",
    options: ["Writing slant", "Blood pressure", "Eye colour", "Foot length"],
    answer: 0,
    explanation: "Writing slant, letter formation, spacing, proportions and line quality may be examined."
  },
  {
    topic: "Digital Forensics",
    question: "What is digital forensics?",
    options: ["Study of fossils", "Recovery and examination of digital evidence", "Study of insects", "Analysis of paint layers only"],
    answer: 1,
    explanation: "Digital forensics involves identifying, preserving, examining and presenting evidence from digital devices."
  },
  {
    topic: "Forensic Biology",
    question: "Which blood component is primarily responsible for clotting?",
    options: ["Red blood cells", "Platelets", "Plasma proteins only", "White blood cells"],
    answer: 1,
    explanation: "Platelets help form a plug and support the blood-clotting process."
  },
  {
    topic: "Forensic Anthropology",
    question: "Forensic anthropology commonly helps examine which evidence?",
    options: ["Skeletal remains", "Computer passwords", "Ink colour only", "Explosive residue only"],
    answer: 0,
    explanation: "Forensic anthropology applies skeletal analysis to assist legal investigations, including examination of human remains."
  },
  {
    topic: "Forensic Entomology",
    question: "Forensic entomology uses the study of which organisms?",
    options: ["Fungi", "Insects and other arthropods", "Bacteria only", "Mosses"],
    answer: 1,
    explanation: "Forensic entomology studies insects and other arthropods associated with legal investigations, sometimes to help estimate a post-mortem interval."
  }
];

const startScreen = document.getElementById("start-screen");
const quizScreen = document.getElementById("quiz-screen");
const resultScreen = document.getElementById("result-screen");
const startBtn = document.getElementById("start-btn");
const nextBtn = document.getElementById("next-btn");
const restartBtn = document.getElementById("restart-btn");
const questionCount = document.getElementById("question-count");
const topicLabel = document.getElementById("topic-label");
const progressFill = document.getElementById("progress-fill");
const questionText = document.getElementById("question-text");
const answerList = document.getElementById("answer-list");
const feedback = document.getElementById("feedback");
const answeredCount = document.getElementById("answered-count");

let currentQuestion = 0;
let score = 0;
let hasAnswered = false;

function showScreen(screen) {
  [startScreen, quizScreen, resultScreen].forEach(item => item.classList.add("hidden"));
  screen.classList.remove("hidden");
}

function startQuiz() {
  currentQuestion = 0;
  score = 0;
  hasAnswered = false;
  showScreen(quizScreen);
  renderQuestion();
}

function renderQuestion() {
  hasAnswered = false;
  const item = questions[currentQuestion];
  const number = currentQuestion + 1;

  questionCount.textContent = `QUESTION ${String(number).padStart(2, "0")} / ${questions.length}`;
  topicLabel.textContent = item.topic.toUpperCase();
  questionText.textContent = item.question;
  progressFill.style.width = `${(currentQuestion / questions.length) * 100}%`;
  answeredCount.textContent = `${currentQuestion} of ${questions.length} answered`;
  feedback.classList.add("hidden");
  feedback.textContent = "";
  nextBtn.disabled = true;
  nextBtn.innerHTML = currentQuestion === questions.length - 1
    ? 'See my result <span>→</span>'
    : 'Next question <span>→</span>';

  answerList.innerHTML = "";
  item.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer-btn";
    button.innerHTML = `<span class="option-letter">${String.fromCharCode(65 + index)}</span><span></span>`;
    button.querySelector("span:last-child").textContent = option;
    button.addEventListener("click", () => selectAnswer(index));
    answerList.appendChild(button);
  });
}

function selectAnswer(selectedIndex) {
  if (hasAnswered) return;
  hasAnswered = true;

  const item = questions[currentQuestion];
  const buttons = [...answerList.querySelectorAll(".answer-btn")];
  buttons.forEach((button, index) => {
    button.disabled = true;
    if (index === item.answer) button.classList.add("correct");
    if (index === selectedIndex && selectedIndex !== item.answer) button.classList.add("incorrect");
  });

  if (selectedIndex === item.answer) {
    score++;
    feedback.textContent = `✓ Correct! ${item.explanation}`;
  } else {
    feedback.textContent = `Not quite. ${item.explanation}`;
  }

  feedback.classList.remove("hidden");
  answeredCount.textContent = `${currentQuestion + 1} of ${questions.length} answered`;
  progressFill.style.width = `${((currentQuestion + 1) / questions.length) * 100}%`;
  nextBtn.disabled = false;
}

function showResults() {
  showScreen(resultScreen);
  const percentage = Math.round((score / questions.length) * 100);
  document.getElementById("score-number").textContent = `${score}/${questions.length}`;
  document.getElementById("score-percent").textContent = `${percentage}% accuracy`;

  let heading = "Keep investigating!";
  let message = "Every great forensic scientist keeps learning. Review the concepts and try again.";
  if (percentage >= 80) {
    heading = "Brilliant investigation!";
    message = "Excellent work. Your forensic science fundamentals are looking strong.";
  } else if (percentage >= 50) {
    heading = "Good detective work!";
    message = "You have a good start. A little more revision will make you even stronger.";
  }
  document.getElementById("result-heading").textContent = heading;
  document.getElementById("result-message").textContent = message;
}

function goToNextQuestion() {
  if (!hasAnswered) return;
  if (currentQuestion < questions.length - 1) {
    currentQuestion++;
    renderQuestion();
  } else {
    showResults();
  }
}

startBtn.addEventListener("click", startQuiz);
nextBtn.addEventListener("click", goToNextQuestion);
restartBtn.addEventListener("click", startQuiz);
